import React, { useCallback, useEffect, useRef, useState } from "react";
import ReactFlow, {
  ReactFlowProvider,
  useNodesState,
  useEdgesState,
  addEdge,
  Background,
  Controls,
  useReactFlow

} from "reactflow";
import "reactflow/dist/style.css";
import Toolbar from "./components/Toolbar.jsx";
import Node from "./components/Node.jsx";
import "./styles/App.css";

const nodeTypes = { custom: Node };

// simple id generator
let idCounter = 1;
const getId = () => `node_${idCounter++}`;

function Canvas() {
  const reactFlowWrapper = useRef(null);
  const { project } = useReactFlow();

  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  // History stacks
  const [history, setHistory] = useState([]);   // past states
  const [future, setFuture] = useState([]);     // undone states for redo

  // Helper: snapshot current state
  const snapshot = useCallback(
    () => ({ nodes: JSON.parse(JSON.stringify(nodes)), edges: JSON.parse(JSON.stringify(edges)) }),
    [nodes, edges]
  );

  // Push current state into history (and clear future)
  const pushHistory = useCallback(() => {
    setHistory((h) => [...h, snapshot()]);
    setFuture([]); // new action invalidates redo stack
  }, [snapshot]);

  // Initialize with empty state (optional)
  useEffect(() => {
    // Only once, seed history with initial empty graph
    setHistory([{ nodes: [], edges: [] }]);
  }, []);

  // Add edge
  const onConnect = useCallback(
    (params) => {
      pushHistory();
      setEdges((eds) =>
        addEdge(
          {
            ...params,
            animated: true,
            style: { stroke: "#4f9eed", strokeWidth: 2 },
          },
          eds
        )
      );
    },
    [setEdges, pushHistory]
  );

  // Add node (toolbar click)
  const addNode = useCallback(
    (payload) => {
      const { label, icon } = payload;
      pushHistory();
      const position = { x: 120 + Math.random() * 400, y: 100 + Math.random() * 300 };
      const newNode = {
        id: getId(),
        type: "custom",
        position,
        data: { label, icon },
      };
      setNodes((nds) => nds.concat(newNode));
    },
    [setNodes, pushHistory]
  );

  // Drag-over and drop (toolbar drag)
  const onDragOver = useCallback((evt) => {
    evt.preventDefault();
    evt.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = useCallback(
    (evt) => {
      evt.preventDefault();
      const raw = evt.dataTransfer.getData("application/reactflow");
      if (!raw) return;

      const { label, icon } = JSON.parse(raw);
      const bounds = reactFlowWrapper.current.getBoundingClientRect();
      const position = project({
        x: evt.clientX - bounds.left,
        y: evt.clientY - bounds.top,
      });

      pushHistory();
      const newNode = {
        id: getId(),
        type: "custom",
        position,
        data: { label, icon },
      };
      setNodes((nds) => nds.concat(newNode));
    },
    [project, setNodes, pushHistory]
  );

  // Delete selected nodes/edges
  const deleteSelected = useCallback(() => {
    const selectedNodeIds = new Set(nodes.filter((n) => n.selected).map((n) => n.id));
    const selectedEdgeIds = new Set(edges.filter((e) => e.selected).map((e) => e.id));

    if (selectedNodeIds.size === 0 && selectedEdgeIds.size === 0) return;

    pushHistory();

    // Remove selected edges
    const remainingEdges = edges.filter((e) => !selectedEdgeIds.has(e.id));

    // Also remove edges connected to deleted nodes
    const remainingEdges2 = remainingEdges.filter(
      (e) => !selectedNodeIds.has(e.source) && !selectedNodeIds.has(e.target)
    );

    // Remove selected nodes
    const remainingNodes = nodes.filter((n) => !selectedNodeIds.has(n.id));

    setEdges(remainingEdges2);
    setNodes(remainingNodes);
  }, [nodes, edges, setNodes, setEdges, pushHistory]);

  // Undo / Redo
  const undo = useCallback(() => {
    if (history.length <= 1) return; // keep at least the seed state
    const prev = history[history.length - 2]; // state to restore
    const current = history[history.length - 1];

    setFuture((f) => [current, ...f]); // move current to future
    setHistory((h) => h.slice(0, -1)); // pop current

    setNodes(prev.nodes);
    setEdges(prev.edges);
  }, [history, setNodes, setEdges]);

  const redo = useCallback(() => {
    if (future.length === 0) return;
    const [next, ...rest] = future;

    // Push current snapshot to history
    setHistory((h) => [...h, snapshot()]);
    setFuture(rest);

    setNodes(next.nodes);
    setEdges(next.edges);
  }, [future, setNodes, setEdges, snapshot]);

  // Keyboard shortcuts: Delete/Backspace, Ctrl/Cmd+Z, Ctrl/Cmd+Shift+Z
  useEffect(() => {
    const onKeyDown = (e) => {
      const tag = (e.target && e.target.tagName) || "";
      // Avoid interfering while typing into inputs/textareas
      if (tag === "INPUT" || tag === "TEXTAREA" || e.target?.isContentEditable) return;

      const isMac = navigator.platform.toUpperCase().includes("MAC");
      const ctrlOrCmd = isMac ? e.metaKey : e.ctrlKey;

      if ((e.key === "Delete" || e.key === "Backspace") && !ctrlOrCmd) {
        e.preventDefault();
        deleteSelected();
        return;
      }
      if (ctrlOrCmd && e.key.toLowerCase() === "z" && !e.shiftKey) {
        e.preventDefault();
        undo();
        return;
      }
      if (ctrlOrCmd && e.key.toLowerCase() === "z" && e.shiftKey) {
        e.preventDefault();
        redo();
        return;
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [undo, redo, deleteSelected]);

  // React Flow callbacks that change selection/positions should still be tracked by RF state.
  // If you want moving nodes to be undoable, you can push history on drag end:
  const onNodesChangeWithHistory = useCallback(
    (changes) => {
      onNodesChange(changes);
      // If a drag ends (position change with dragging=false), snapshot
      if (changes.some((c) => c.type === "position" && c.dragging === false)) {
        setHistory((h) => [...h, snapshot()]);
        setFuture([]);
      }
    },
    [onNodesChange, snapshot]
  );

  const onEdgesChangeWithHistory = useCallback(
    (changes) => {
      onEdgesChange(changes);
      // Edge selection changes don’t need snapshot; actual add/remove already handled elsewhere
    },
    [onEdgesChange]
  );

  return (
    <div className="app-root" ref={reactFlowWrapper}>
      {/* Top Toolbar with extra controls */}
      <Toolbar onAddClick={addNode}>
        <div className="toolbar-actions">
          <button className="btn" onClick={undo} title="Undo (Ctrl/Cmd+Z)">↩️ Undo</button>
          <button className="btn" onClick={redo} title="Redo (Ctrl/Cmd+Shift+Z)">↪️ Redo</button>
          <button className="btn danger" onClick={deleteSelected} title="Delete (Del/Backspace)">🗑️ Delete</button>
        </div>
      </Toolbar>

      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        onNodesChange={onNodesChangeWithHistory}
        onEdgesChange={onEdgesChangeWithHistory}
        onConnect={onConnect}
        onDrop={onDrop}
        onDragOver={onDragOver}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        proOptions={{ hideAttribution: true }}
      >
        <Background color="#3a3a3a" gap={18} />
        <Controls />
      </ReactFlow>
    </div>
  );
}

export default function App() {
  return (
    <ReactFlowProvider>
      <Canvas />
    </ReactFlowProvider>
  );
}
