import React from "react";
import "../styles/Toolbar.css";

const ITEMS = [
  { label: "Start", icon: "▶️" },
  { label: "AI Model", icon: "🤖" },
  { label: "Script", icon: "📜" },
  { label: "Instruction", icon: "📝" },
  { label: "Upload File", icon: "📂" },
  { label: "Logic IF/ELSE", icon: "🔀" },
];

export default function Toolbar({ onAddClick, children }) {
  const onDragStart = (evt, item) => {
    evt.dataTransfer.setData("application/reactflow", JSON.stringify(item));
    evt.dataTransfer.effectAllowed = "move";
  };

  return (
    <div className="toolbar">
      <div className="toolbar-left">
        {ITEMS.map((item) => (
          <div
            key={item.label}
            className="tool"
            draggable
            onDragStart={(e) => onDragStart(e, item)}
            onClick={() => onAddClick(item)}
            title={`Add ${item.label}`}
          >
            <span className="tool-emoji">{item.icon}</span>
            <span className="tool-label">{item.label}</span>
          </div>
        ))}
      </div>
      <div className="toolbar-right">
        {children}
      </div>
    </div>
  );
}
