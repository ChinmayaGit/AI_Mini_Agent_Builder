// components/Node.jsx
import React from "react";
import { Handle, Position, NodeResizer } from "reactflow";
import "../styles/Node.css";

export default function Node({ selected, data }) {
  const icon = data?.icon ?? "🧩";
  const label = data?.label ?? "Node";
  const kind = data?.kind ?? "generic";
  const status = data?.status ?? "idle";

  return (
    <div className="node-shell">
      <NodeResizer
        isVisible={selected}
        minWidth={220}
        minHeight={90}
        lineStyle={{ stroke: "#4f9eed" }}
        handleStyle={{ width: 8, height: 8, borderRadius: 2, background: "#4f9eed" }}
      />

      <div className="node-body">
        <div className="node-title">
          <span className="node-icon">{icon}</span>
          <span className="node-text">{label}</span>
          <span className={`badge badge-${status}`}>{status}</span>
        </div>

        <div className="node-content">
          {kind === "start" && <StartUI data={data} />}
          {kind === "upload" && <UploadUI data={data} />}
          {kind === "script" && <ScriptUI data={data} />}
          {kind === "ai" && <AIUI data={data} />}
          {kind === "analysis" && <AnalysisUI data={data} />}
          {kind === "check" && <CheckUI data={data} />}
        </div>
      </div>

      {/* Handles: both source and target each side */}
      <Handle id="t" className="handle handle-top" type="target" position={Position.Top} />
      <Handle id="t-src" className="handle handle-top" type="source" position={Position.Top} />
      <Handle id="l" className="handle handle-left" type="target" position={Position.Left} />
      <Handle id="l-src" className="handle handle-left" type="source" position={Position.Left} />
      <Handle id="r" className="handle handle-right" type="target" position={Position.Right} />
      <Handle id="r-src" className="handle handle-right" type="source" position={Position.Right} />
      <Handle id="b" className="handle handle-bottom" type="target" position={Position.Bottom} />
      <Handle id="b-src" className="handle handle-bottom" type="source" position={Position.Bottom} />
    </div>
  );
}

/* UI Fragments: keep them dumb; actions are dispatched via CustomEvent */
function StartUI() {
  return (
    <div className="ui-row">
      <button
        className="btn tool"
        onClick={() => window.dispatchEvent(new CustomEvent("rf/run-from-start", {}))}
      >
        ▶️ Run
      </button>
    </div>
  );
}

function UploadUI({ data }) {
  return (
    <div className="ui-col">
      <input
        className="input"
        type="file"
        accept=".csv"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) {
            window.dispatchEvent(new CustomEvent("rf/upload", { detail: { nodeId: data.id, file } }));
          }
        }}
      />
      <small className="hint">{data?.config?.filename || "No file selected"}</small>
    </div>
  );
}

function ScriptUI({ data }) {
  return (
    <div className="ui-col">
      <select
        className="input"
        value={data?.config?.script || "check_csv_present"}
        onChange={(e) => {
          window.dispatchEvent(new CustomEvent("rf/update-config", {
            detail: { nodeId: data.id, patch: { script: e.target.value } },
          }));
        }}
      >
        <option value="check_csv_present">Check CSV present</option>
        <option value="regen_model">Regenerate model</option>
      </select>
      <button
        className="btn tool"
        onClick={() =>
          window.dispatchEvent(new CustomEvent("rf/run-node", { detail: { nodeId: data.id } }))
        }
      >
        ▶️ Run
      </button>
    </div>
  );
}

function AIUI({ data }) {
  return (
    <div className="ui-col">
      <input
        className="input"
        type="text"
        placeholder="Prompt or model cmd..."
        value={data?.config?.prompt || ""}
        onChange={(e) =>
          window.dispatchEvent(new CustomEvent("rf/update-config", {
            detail: { nodeId: data.id, patch: { prompt: e.target.value } },
          }))
        }
      />
      <button
        className="btn tool"
        onClick={() =>
          window.dispatchEvent(new CustomEvent("rf/run-node", { detail: { nodeId: data.id } }))
        }
      >
        🤖 Run
      </button>
    </div>
  );
}

function AnalysisUI({ data }) {
  return (
    <div className="ui-col">
      <div className="ui-row">
        <button className="btn tool" onClick={() => window.dispatchEvent(new CustomEvent("rf/analysis", { detail: { nodeId: data.id, op: "row_count" } }))}>Rows</button>
        <button className="btn tool" onClick={() => window.dispatchEvent(new CustomEvent("rf/analysis", { detail: { nodeId: data.id, op: "unique_users" } }))}>Unique users</button>
      </div>
      <input
        className="input"
        type="text"
        placeholder='Question e.g. "how many users with no manager"'
        value={data?.config?.question || ""}
        onChange={(e) =>
          window.dispatchEvent(new CustomEvent("rf/update-config", {
            detail: { nodeId: data.id, patch: { question: e.target.value } },
          }))
        }
      />
      <button className="btn tool" onClick={() => window.dispatchEvent(new CustomEvent("rf/analysis", { detail: { nodeId: data.id, op: "question" } }))}>Ask</button>
    </div>
  );
}

function CheckUI({ data }) {
  return (
    <div className="ui-col">
      <button
        className="btn tool"
        onClick={() =>
          window.dispatchEvent(new CustomEvent("rf/run-node", { detail: { nodeId: data.id } }))
        }
      >
        ✅ Run checks
      </button>
      <small className="hint">Examples: users without manager, invalid emails, etc.</small>
    </div>
  );
}
